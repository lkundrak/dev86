/*
 * Match e-mail addresses: they match, if the username (before @) and
 * all but the last levels of the domains match. One set of addresses
 * comes from stdin, another from filen given on command line. Return success
 * (EXIT_SUCCESS), if any of the addresses in the file matches
 * any of the addresses in stdin; otherwise fail (EXIT_FAILURE).
 *
 * Addresses in stdin must be one per line, and at most MAX_LINE characters
 * per address. There may be at most MAX_ADDRESSES addresses.
 *
 * Test cases:
 *
 *	File:
 *
 *		foo@bar.com
 *		foo@foobar.bar.com
 *		FOO@bar.com
 *		bar@bar.com
 *
 *	Stdin (one for each test):		Expected result:
 *
 *		foo@bar.com (Foo bar)		match
 *		Foo bar <foo@barbar.bar.com>	match
 *		foo@foo.com			no match
 *		foo@bar.bar.bar.com		no match
 *
 * Lars Wirzenius.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <publib.h>

#ifndef MAX_LINE
#define MAX_LINE 1024
#endif

#ifndef MAX_ADDRESSES
#define MAX_ADDRESSES (10*1024)
#endif

#if 0
#define TRACE(a)	printf a
#else
#define TRACE(a)	((void) 0)
#endif

static char *after(char *str, int c) {
	char *p;
	
	p = strchr(str, c);
	if (p == NULL)
		return str;
	return p + 1;
}

static int compare2(char *aa, char *bb) {
	char *adom, *adom1, *bdom, *bdom1;
	size_t len;
	
	adom = after(aa, '@');
	adom1 = after(adom, '.');
	if (strchr(adom1, '.') == NULL)
		adom1 = adom;

	bdom = after(bb, '@');
	bdom1 = after(bdom, '.');
	if (strchr(bdom1, '.') == NULL)
		bdom1 = bdom;

	len = adom - aa;
	TRACE(("comparing <%s> and <%s>\n", aa, bb));
	TRACE(("  username len = %d\n", (int) len));
	TRACE(("  adom = <%s>, adom1 = <%s>\n", adom, adom1));
	TRACE(("  bdom = <%s>, bdom1 = <%s>\n", bdom, bdom1));
	if (strncasecmp(aa, bb, len) == 0 && len > 0 && bb[len-1] == '@') {
		TRACE(("  usernames are equal...\n"));
		if (strcasecmp(adom, bdom) == 0 ||
		    strcasecmp(adom, bdom1) == 0 ||
		    strcasecmp(adom1, bdom) == 0 ||
		    strcasecmp(adom1, bdom1) == 0)
			return 0;
		TRACE(("  but domains differ\n"));
	}

	TRACE(("  comparing full addresses\n"));
	return strcasecmp(aa, bb);
}

static int readline(char *buf, FILE *f) {
	char *p;
	int c;
	for (;;) {
		if (fgets(buf, MAX_LINE, f) == NULL)
			return 0;
		p = strchr(buf, '\n');
		if (p != NULL)
			break;
		while ((c = getc(f)) != EOF && c != '\n')
			continue;
	}
	*p = '\0';
	return 1;
}

int main(int argc, char **argv) {
	static char *addr[MAX_ADDRESSES];
	static char buf[MAX_LINE+1];
	int i, naddr;
	char *p;
	FILE *f;
	
	if (argc < 2)
		return EXIT_SUCCESS;

	naddr = 0;
	for (i = 1; i < argc; ++i) {
		f = fopen(argv[i], "r");
		if (f == NULL)
			continue;
		while (naddr < MAX_ADDRESSES && readline(buf, f)) {
			strtrim(buf);
			p = strdup(buf);
			if (p != NULL)
				addr[naddr++] = p;
		}
		fclose(f);
	}

	TRACE(("naddr = %d\n", (int) naddr));
	while (readline(buf, stdin)) {
		strtrim(buf);
		TRACE(("got address <%s>\n", buf));
		for (i = 0; i < naddr; ++i) {
			if (compare2(addr[i], buf) == 0)
				exit(EXIT_SUCCESS);
		}
	}

	exit(EXIT_FAILURE);
}
